# 14. SUBNETTING : PART 2

CLASS C NETWORKS

![image](https://github.com/psaumur/CCNA/assets/106411237/08be5a37-fa2c-4483-94c9-6c3d05229894)


CLASS B NETWORKS

![image](https://github.com/psaumur/CCNA/assets/106411237/44e8cdcb-16c2-41c4-8f22-a0a31071550a)
